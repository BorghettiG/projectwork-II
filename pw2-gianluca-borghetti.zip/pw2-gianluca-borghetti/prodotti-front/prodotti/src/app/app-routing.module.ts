import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProdottiListComponent } from './prodotti-list/prodotti-list.component';
import { ProdottiComponent } from './prodotti/prodotti.component';

const routes: Routes = [
  { path: '', component: ProdottiListComponent },
  { path: 'prodotto', component: ProdottiListComponent },
  { path: 'prodotto/:id', component: ProdottiComponent },

  // otherwise redirect to home
  { path: '**', redirectTo: '' },
];



  // otherwise redirect to home
 // { path: '**', redirectTo: '' },
//];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

