import { Component, OnInit } from '@angular/core';
import { Prodotto } from '../prodotti.model';
import { ProdottoService } from '../prodotti.service';

@Component({
  selector: 'app-prodotti-list',
  templateUrl: './prodotti-list.component.html',
  styleUrl: './prodotti-list.component.css'
})


export class ProdottiListComponent implements OnInit {
  prodottiList: Prodotto[] = [];

  searchTerm: string = '';

  constructor(public prodottoService: ProdottoService) {}

  ngOnInit(): void {
    this.prodottoService.getProdottiList().then((list) => {
      this.prodottiList = list;
    });
  }

  onSearch(event: Event) {
    this.searchTerm = (event.target as HTMLInputElement).value;
    console.log('onSearch: ', this.searchTerm);

    /*this.prodottoService.searchProdotto(this.searchTerm).then((list) => {
      if (list != null && list.length === 0) {
        this.prodottiList = list;*/

    
    this.prodottoService.getProdottiList()
    .then(
      (list) => {
        if (this.searchTerm == null || this.searchTerm.length === 0) {
        this.prodottiList = list;
        } else {
        this.prodottiList = list.filter((prodotto) => {
          if (
            prodotto.name != null &&
            prodotto.name.toLowerCase().indexOf(this.searchTerm.toLowerCase()) >= 0
          ) {
            return true;
          } else {
            return false;
          }
        });
      }
    });
  }
} 
   

 