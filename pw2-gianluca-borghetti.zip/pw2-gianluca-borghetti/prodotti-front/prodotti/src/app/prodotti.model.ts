/*In questo file prodotti.model.ts vengono costruiti liberamente il modello del frontend e 
ripreso dal file progetto Laravel il modello del backend


Questa classe dichiara le proprieta' che gli oggetti prodotto istanziati assumeranno*/
export class Prodotto {
    public id?: string;
    public name?: string;
    public price?: number;
    public category_id?: number;

  }
  
  /*Questa classe dichiara le proprieta' che gli oggetti prodotto istanziati assumeranno, in questo caso riprendendole dal modello di backend Laravel*/
  export class BackProdotto {
    public id?: string;
    public name?: string;
    public price?: number;
    public category_id?: number;
  }

  /* questa classe mi restituisce il risultato di una ricerca e il numero degli item*/

  
export class BackSearchResponse {
    Response?: string;
  
    // Response == "True"
    Search?: BackProdotto[];
    totalResults?: string;
  
    // Response == "False"
    Error?: string;
  }
 





