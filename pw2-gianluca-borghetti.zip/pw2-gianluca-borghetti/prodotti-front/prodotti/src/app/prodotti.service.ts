import { Injectable } from '@angular/core';
import { Prodotto, BackProdotto, BackSearchResponse } from './prodotti.model';
import { HttpClient } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';






@Injectable({
providedIn: 'root'
})

export class ProdottoService {
prodottoList: Prodotto [] = [];
idList: number[] = [];
baseUrl?:'http://localhost:8000/api';


/* COSTRUTTORE*/
 constructor(private http: HttpClient) {
  for (let i = 0; i < this.idList.length; i++) {
    console.log('idList', this.idList[i]);
    console.log('idList', this.idList.length);
    console.log('idList', this.idList);

    this.getProdotto(
      this.baseUrl + '/products/'
      + this.idList[i]    
    )
      .then((p) => {
        this.prodottoList.push(p);
      })
      .catch((err) =>
        console.warn(
          'ProdottiService.init(): fallito caricamento del prodotto id = ' +
            this.idList[i]
        )
      );
  }
}

/*getProdotto(url: string): Promise<Prodotto> {
  return this.http.get<Prodotto>(url)
  .toPromise();
  }*/


 getProdotto(id: string): Promise<Prodotto> {
  return this.http
    .get<BackProdotto>('http://localhost:8000/api/products/' + id)
    .toPromise()
    .then((opr) => {
      const p: Prodotto = new Prodotto();
      p.id = opr?.id;
      p.name = opr?.name;
      p.price = opr?.price;
      p.category_id = opr?.category_id;
      /*p.imageUrl = opr?.imageUrl;*/
      return p;
    });
}
/*getProdotto(arg0: string) {
  throw new Error('Method not implemented.');
  }*/



  getProdottiList(): Promise<Prodotto[]> {
    return Promise.resolve(this.prodottoList);
 }





  

  searchProdotto(term: string): Promise<Prodotto[]> {
    if (term == null || term.length == 0) {
      return Promise.resolve([]);
    } else {
      return this.http
        .get<BackSearchResponse>(
          'http://localhost:8000/api/products' +
            '&s=' +
            term +
            '&page=1'
          )
          .toPromise()
          .then((osr) => {
            if (osr?.Response === 'True' && osr.Search != null) {
              const backprodottiList = osr.Search;
              const prodottiList: Prodotto[] = backprodottiList?.map((o) => {
                const p: Prodotto = new Prodotto();
                p.id = o?.id;
                p.name = o?.name;
                p.price = o?.price;
                /*p.imageUrl = o?.opera;*/
                p.category_id = o?.category_id;
                
                return p;
              });
              return prodottiList != null ? prodottiList : [];
            } else {
              return [];
            }
          });
      }
    }


   /* Oggetto da backend

    'name' => ['required', 'min:2'],
    'price' => ['required', 'decimal:2,2'],
    'category_id' => ['required', 'exists:categories,id'],*/




}
