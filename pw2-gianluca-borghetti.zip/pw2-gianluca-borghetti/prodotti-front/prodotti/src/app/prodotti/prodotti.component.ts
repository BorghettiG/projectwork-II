
import { Component, Input, OnInit } from '@angular/core';
import { ProdottoService } from '../prodotti.service';
import { Prodotto } from '../prodotti.model';
import { ActivatedRoute } from '@angular/router';



@Component({
  selector: 'app-prodotti',
  templateUrl: './prodotti.component.html',
  styleUrl: './prodotti.component.css'
})
export class ProdottiComponent implements OnInit {
  @Input() prodotto: Prodotto | null = null;

  errorMessage: string | null = null;

  constructor(
    public prodottoService: ProdottoService,
    private activatedRoute: ActivatedRoute
  ) {}

  ngOnInit(): void {
    const id = this.activatedRoute.snapshot.paramMap.get('id');
    console.log('ProdottiComponent.ngOnInit(): prodotto id=', id);
    if (id != null) {
      // const p: Promise<Film> = this.filmService.getFilm(Number(id));
      // p.then(f => this.film = f);
      // p.catch(err => console.error(err));

      this.prodottoService
        .getProdotto(id)
        .then((p: Prodotto
        ) => {
          this.prodotto = p;
          console.log('ProdottiComponent.ngOnInit(): prodotto ', this.prodotto);
        })
        /* Qui ho trovato difficolta' poi con l'aiuto dell'AI 
        ho capito che voleva la tipizzazione sulla variabile oggetto err */
        .catch((err: string
        ) => {
          this.errorMessage = err;
          console.error(err);
        });
    }
  }
}
        
        
   